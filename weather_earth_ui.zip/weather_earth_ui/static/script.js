const map = L.map('map', {
  zoomControl: false,
  worldCopyJump: true,
}).setView([23.5880, 58.3829], 6);

L.control.zoom({ position: 'bottomleft' }).addTo(map);

L.tileLayer(
  'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  {
    maxZoom: 19,
    attribution: 'Tiles © Esri — Weather © OpenWeatherMap',
  }
).addTo(map);

let marker = null;

const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const weatherPanel = document.getElementById('weatherPanel');
const loading = document.getElementById('loading');

function showLoading(show) {
  loading.style.display = show ? 'block' : 'none';
}

function showError(message) {
  weatherPanel.innerHTML = `
    <div class="empty-state error">
      <h2>Something went wrong ⚠️</h2>
      <p>${message}</p>
    </div>
  `;
}

function updateMarker(lat, lon, label) {
  if (marker) {
    map.removeLayer(marker);
  }

  marker = L.marker([lat, lon]).addTo(map);
  marker.bindPopup(label || 'Selected location').openPopup();
  map.flyTo([lat, lon], 10, {
    animate: true,
    duration: 1.8,
  });
}

function renderWeather(data) {
  const iconUrl = data.icon
    ? `https://openweathermap.org/img/wn/${data.icon}@2x.png`
    : '';

  weatherPanel.innerHTML = `
    <div class="weather-header">
      <div>
        <h2>${data.city || 'Selected Area'}, ${data.country || ''}</h2>
        <p>${data.description || 'Weather details'}</p>
      </div>
      ${iconUrl ? `<img class="weather-icon" src="${iconUrl}" alt="weather icon" />` : ''}
    </div>

    <div class="temp">${data.temperature}<span>°C</span></div>

    <div class="weather-grid">
      <div class="weather-card">
        <small>Feels like</small>
        <strong>${data.feels_like}°C</strong>
      </div>
      <div class="weather-card">
        <small>Humidity</small>
        <strong>${data.humidity}%</strong>
      </div>
      <div class="weather-card">
        <small>Wind speed</small>
        <strong>${data.wind_speed} m/s</strong>
      </div>
      <div class="weather-card">
        <small>Pressure</small>
        <strong>${data.pressure} hPa</strong>
      </div>
    </div>
  `;

  if (data.lat && data.lon) {
    updateMarker(data.lat, data.lon, `${data.city || 'Selected location'}: ${data.temperature}°C`);
  }
}

async function fetchWeatherByCity(city) {
  if (!city.trim()) {
    showError('Please enter a city name first.');
    return;
  }

  showLoading(true);
  try {
    const res = await fetch(`/api/weather?city=${encodeURIComponent(city.trim())}`);
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'City not found.');
    }

    renderWeather(data);
  } catch (error) {
    showError(error.message);
  } finally {
    showLoading(false);
  }
}

async function fetchWeatherByCoords(lat, lon) {
  showLoading(true);
  try {
    const res = await fetch(`/api/weather?lat=${lat}&lon=${lon}`);
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Weather not found for this location.');
    }

    renderWeather(data);
  } catch (error) {
    showError(error.message);
  } finally {
    showLoading(false);
  }
}

searchBtn.addEventListener('click', () => fetchWeatherByCity(cityInput.value));

cityInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    fetchWeatherByCity(cityInput.value);
  }
});

document.querySelectorAll('[data-city]').forEach((btn) => {
  btn.addEventListener('click', () => {
    cityInput.value = btn.dataset.city;
    fetchWeatherByCity(btn.dataset.city);
  });
});

map.on('click', (event) => {
  const { lat, lng } = event.latlng;
  fetchWeatherByCoords(lat.toFixed(5), lng.toFixed(5));
});

fetchWeatherByCity('Muscat');
